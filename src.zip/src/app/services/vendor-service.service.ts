import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Cuisine } from '../Cuisine';
import { Restaurant } from '../Restaurant';

@Injectable({
  providedIn: 'root'
})
export class VendorServiceService {

  baseurl = "http://localhost:9300/api/v5/vendor";

  getAllRestaurantList() : Observable<Restaurant[]>{

    return this.httpClient.get<Restaurant[]>(`${this.baseurl}/getAllRestaurant`);

  }
  getCuisineNames(id : String) : Observable<Cuisine>{

    return this.httpClient.get<Cuisine>(`${this.baseurl}/getCuisineName/${id}`);
  }

  constructor(private httpClient : HttpClient) { }
}
