export class Location{
    street : String="";
    landmark : String="";
    state : String="";
    city : String="";
    zipcode : number=0;
    locLat : number=0;
    LocLong : number=0;
}