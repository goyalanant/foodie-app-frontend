export class users{
    [x: string]: any;

    userEmail : String | undefined;
    userPassword : String | undefined;
}