export class Cuisine{

    cuisineId : String="";
    cuisineName : String="";
    cuisineImages : Array<String>=[];
    restaurantIds : Array<String> =[];
}