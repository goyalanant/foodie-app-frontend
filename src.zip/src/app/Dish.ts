export class Dish{

    dishId : String="";
    dishName: String="";
    dishWeight : Array<number>=[];
    dishPrice : Array<number>=[];
    dishImages : Array<String>=[];
    cuisineId: String="";
    inStock : boolean=true;
}